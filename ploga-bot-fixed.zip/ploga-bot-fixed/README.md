# ploga-bot fixed

קבצים מוכנים ל-Render Web Service חינמי.

## Render settings

Build Command:
```bash
pip install -r requirements.txt
```

Start Command:
```bash
uvicorn bot:app --host 0.0.0.0 --port $PORT
```

Environment Variables:

```txt
TELEGRAM_TOKEN=הטוקן החדש מבוטפאדר
SHEET_CSV_URL=https://docs.google.com/spreadsheets/d/1FfsoH6nBfOIns0KhCFnNOC3E8OLibo-eA1JyTC3ubn8/export?format=csv&gid=0
WEBHOOK_URL=https://ploga-bot-1.onrender.com
```

לא להעלות טוקן לגיטהאב.
