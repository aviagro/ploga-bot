import os
import time
import logging
from io import StringIO

import pandas as pd
import requests
from fastapi import FastAPI, Request
from telegram import Update, Bot
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters

logging.basicConfig(level=logging.INFO)

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
SHEET_CSV_URL = os.getenv("SHEET_CSV_URL")
WEBHOOK_URL = os.getenv("WEBHOOK_URL")

if not TELEGRAM_TOKEN:
    raise ValueError("Missing TELEGRAM_TOKEN")

if not SHEET_CSV_URL:
    raise ValueError("Missing SHEET_CSV_URL")

if not WEBHOOK_URL:
    raise ValueError("Missing WEBHOOK_URL")

app = FastAPI()
bot = Bot(token=TELEGRAM_TOKEN)
telegram_app = Application.builder().token(TELEGRAM_TOKEN).build()

CACHE = {"df": None, "last_loaded": 0}
CACHE_SECONDS = 300


def load_sheet(force=False):
    now = time.time()
    if not force and CACHE["df"] is not None and now - CACHE["last_loaded"] < CACHE_SECONDS:
        return CACHE["df"]

    response = requests.get(SHEET_CSV_URL, timeout=10)
    response.raise_for_status()

    df = pd.read_csv(StringIO(response.text), dtype=str).fillna("")
    df.columns = [str(c).strip() for c in df.columns]

    CACHE["df"] = df
    CACHE["last_loaded"] = now
    return df


def value(row, col):
    if col not in row:
        return ""
    return str(row[col]).strip()


def format_row(row):
    fields = [
        ("שם", "שם החייל"),
        ("מספר אישי", "מספר אישי"),
        ("צוות", "צוות"),
        ("נשק", "נשק"),
        ("מספר נשק", "מספר נשק"),
        ("כוונת", "כוונת"),
        ("מספר כוונת", "מספר"),
        ("סוג אמרל", "סוג אמרל"),
        ("מספר אמרל", "מספר אמרל"),
        ("אמרל נוסף", "אמרל נוסף"),
        ("מתי חתם", "מתי חתם"),
        ("זוכה", "זוכה"),
        ("מעבר על הנשק", "מעבר על הנשק"),
    ]

    lines = []
    for label, col in fields:
        val = value(row, col)
        if val:
            lines.append(f"{label}: {val}")

    return "\n".join(lines) if lines else "אין נתונים להצגה"


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "פקודות:\n"
        "שלח שם חייל או מספר לחיפוש\n"
        "/רשימה - הצגת 10 חיילים\n"
        "/עמודות - הצגת עמודות הגיליון\n"
        "/רענון - טעינה מחדש של הגיליון"
    )
    await update.message.reply_text(text)


async def columns(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        df = load_sheet()
        await update.message.reply_text("עמודות בגיליון:\n\n" + " | ".join(df.columns))
    except Exception:
        logging.exception("columns error")
        await update.message.reply_text("שגיאה בטעינת העמודות")


async def list_soldiers(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        df = load_sheet()
        if "שם החייל" not in df.columns:
            await update.message.reply_text("חסרה עמודה בשם: שם החייל")
            return

        lines = []
        seen = set()
        for _, row in df.iterrows():
            name = value(row, "שם החייל")
            if not name or name in seen:
                continue
            seen.add(name)
            team = value(row, "צוות")
            lines.append(name + (f" | {team}" if team else ""))
            if len(lines) >= 10:
                break

        if not lines:
            await update.message.reply_text("לא נמצאו חיילים ברשימה")
            return

        await update.message.reply_text("רשימת חיילים:\n\n" + "\n".join(lines))
    except Exception:
        logging.exception("list error")
        await update.message.reply_text("שגיאה בטעינת הרשימה")


async def refresh(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        df = load_sheet(force=True)
        await update.message.reply_text(f"הגיליון נטען מחדש. נמצאו {len(df)} שורות.")
    except Exception:
        logging.exception("refresh error")
        await update.message.reply_text("שגיאה ברענון הגיליון")


async def search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = (update.message.text or "").strip()
    if not query:
        return

    try:
        df = load_sheet()
        search_columns = [
            "שם החייל",
            "מספר אישי",
            "צוות",
            "נשק",
            "מספר נשק",
            "כוונת",
            "מספר",
            "סוג אמרל",
            "מספר אמרל",
            "אמרל נוסף",
            "זוכה",
            "מעבר על הנשק",
        ]
        existing_cols = [c for c in search_columns if c in df.columns]

        q = query.lower()
        results = []
        seen = set()
        for _, row in df.iterrows():
            for col in existing_cols:
                if q in value(row, col).lower():
                    name = value(row, "שם החייל")
                    key = name or str(row.to_dict())
                    if key not in seen:
                        seen.add(key)
                        results.append(row)
                    break

        if not results:
            await update.message.reply_text(f"לא נמצא: {query}")
            return

        parts = []
        if len(results) > 1:
            parts.append(f"נמצאו {len(results)} תוצאות:\n")

        for row in results[:5]:
            parts.append(format_row(row))
            parts.append("")

        if len(results) > 5:
            parts.append(f"...ועוד {len(results) - 5} תוצאות")

        await update.message.reply_text("\n".join(parts).strip())
    except Exception:
        logging.exception("search error")
        await update.message.reply_text("שגיאה בחיפוש")


telegram_app.add_handler(CommandHandler(["start", "help"], start))
telegram_app.add_handler(CommandHandler(["עמודות", "columns"], columns))
telegram_app.add_handler(CommandHandler(["רשימה", "list"], list_soldiers))
telegram_app.add_handler(CommandHandler(["רענון", "refresh"], refresh))
telegram_app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, search))


@app.on_event("startup")
async def on_startup():
    await telegram_app.initialize()
    await telegram_app.start()
    webhook_url = WEBHOOK_URL.rstrip("/") + "/webhook"
    await bot.set_webhook(webhook_url)
    logging.info("Webhook set to %s", webhook_url)


@app.on_event("shutdown")
async def on_shutdown():
    await telegram_app.stop()
    await telegram_app.shutdown()


@app.get("/")
async def root():
    return {"status": "ok"}


@app.get("/health")
async def health():
    return {"status": "healthy"}


@app.post("/webhook")
async def webhook(request: Request):
    data = await request.json()
    update = Update.de_json(data, bot)
    await telegram_app.process_update(update)
    return {"ok": True}
